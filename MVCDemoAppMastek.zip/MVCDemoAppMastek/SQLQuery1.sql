﻿select * from Categories
select * from Products