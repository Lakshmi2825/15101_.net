﻿using System;
using System.Collections.Generic;

#nullable disable

namespace MVCDemoAppMastek.Models
{
    public partial class Userdatum
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
