﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace HRLib
{
    public class Employee
    {
        #region Fiels & Properties
        private string empName; public string EmpName
        {
            get { return empName; }
            set { empName = value; }
        }
        public string address; public string Address
        {
            get { return address; }
            protected set { address = value; }
        }
        #endregion
        #region Constructor
        public Employee()
        {
            EmpName = "Lakshmi";
            Address = "mahape";
        }
        public Employee(string name, string address)
        {
            this.EmpName = name;
            this.Address = address;
        }
        #endregion
        #region Methods
        public override string ToString()
        {
            return string.Format($"Employee Name: {EmpName} Address: {Address}");
        }
        #endregion



    }
}