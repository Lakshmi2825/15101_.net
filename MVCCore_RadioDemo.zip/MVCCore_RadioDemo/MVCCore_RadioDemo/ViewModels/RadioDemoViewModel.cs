﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MVCCore_RadioDemo.ViewModels;
using MVCCore_RadioDemo.Models;





namespace MVCCore_RadioDemo.ViewModels
{
    public class RadioDemoViewModel
    {
        public string Country { get; set; }
        public List<string> CountryList { get; set; }
        public List<Employee> Employees { get; set; }
    }
}